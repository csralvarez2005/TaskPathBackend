package TaskPathBackend.service.impl;



import TaskPathBackend.dto.UsuarioDTO;
import TaskPathBackend.entity.Usuario;
import TaskPathBackend.exception.UsuarioAlreadyExistsException;
import TaskPathBackend.mapper.UsuarioMapper;
import TaskPathBackend.repository.UsuarioRepository;
import TaskPathBackend.service.UsuarioService;
import TaskPathBackend.service.SequenceGeneratorService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final SequenceGeneratorService sequenceGenerator;
    private final UsuarioMapper usuarioMapper;

    public UsuarioServiceImpl(
            UsuarioRepository usuarioRepository,
            SequenceGeneratorService sequenceGenerator,
            UsuarioMapper usuarioMapper
    ) {
        this.usuarioRepository = usuarioRepository;
        this.sequenceGenerator = sequenceGenerator;
        this.usuarioMapper = usuarioMapper;
    }

    @Override
    public UsuarioDTO crearUsuario(UsuarioDTO usuarioDTO) {
        Usuario usuario = usuarioMapper.toEntity(usuarioDTO);

        // Validar identificación única
        usuarioRepository.findByIdentificacion(usuario.getIdentificacion())
                .ifPresent(u -> {
                    throw new UsuarioAlreadyExistsException(usuario.getIdentificacion());
                });

        // Generar secuencia si no viene ID
        if (usuario.getId() == null) {
            usuario.setId(sequenceGenerator.generateSequence("usuarios_sequence"));
        }

        Usuario saved = usuarioRepository.save(usuario);
        return usuarioMapper.toDTO(saved);
    }

    @Override
    public List<UsuarioDTO> listarUsuarios() {
        return usuarioMapper.toDTOList(usuarioRepository.findAll());
    }

    @Override
    public UsuarioDTO buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email)
                .map(usuarioMapper::toDTO)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con email: " + email));
    }

    @Override
    public UsuarioDTO obtenerUsuario(Long id) {
        return usuarioRepository.findById(id)
                .map(usuarioMapper::toDTO)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con id: " + id));
    }

    @Override
    public void eliminarUsuario(Long id) {
        usuarioRepository.deleteById(id);
    }
}