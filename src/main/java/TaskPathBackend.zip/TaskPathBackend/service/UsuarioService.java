package TaskPathBackend.service;

import TaskPathBackend.dto.UsuarioDTO;
import TaskPathBackend.entity.Usuario;

import java.util.List;

public interface UsuarioService {
    UsuarioDTO crearUsuario(UsuarioDTO usuarioDTO);
    List<UsuarioDTO> listarUsuarios();
    UsuarioDTO buscarPorEmail(String email);
    UsuarioDTO obtenerUsuario(Long id);
    void eliminarUsuario(Long id);
}
