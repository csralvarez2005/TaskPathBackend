package TaskPathBackend.service;

import TaskPathBackend.entity.Cargo;

import java.util.List;

public interface CargoService {
    List<Cargo> listarTodos();
}
